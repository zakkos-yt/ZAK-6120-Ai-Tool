const distros = [
  { id: "ubuntu", name: "Ubuntu", color: "#E95420" },
  { id: "linuxmint", name: "Linux Mint", color: "#86BE43" },
  { id: "lmde", name: "LMDE", color: "#6FAF3A", logo: "linuxmint" },
  { id: "debian", name: "Debian", color: "#A81D33" },
  { id: "fedora", name: "Fedora", color: "#51A2DA" },
  { id: "archlinux", name: "Arch Linux", color: "#1793D1" },
  { id: "manjaro", name: "Manjaro", color: "#35BFA4" },
  { id: "opensuse", name: "openSUSE", color: "#73BA25" },
  { id: "popos", name: "Pop!_OS", color: "#48B9C7" },
  { id: "zorin", name: "Zorin OS", color: "#15A6F0" },
  { id: "almalinux", name: "AlmaLinux", color: "#0F4266" },
  { id: "rockylinux", name: "Rocky Linux", color: "#10B981" },
  { id: "proxmox", name: "Proxmox VE", color: "#E57000" },
  { id: "truenas", name: "TrueNAS SCALE", color: "#0095D5" },
  { id: "slackware", name: "Slackware", color: "#000000" },
  { id: "elementary", name: "elementary OS", color: "#64BAFF" },
  { id: "mxlinux", name: "MX Linux", color: "#222222" },
  { id: "windows95", name: "Windows 95", color: "#008080", logo: "windows" },
  { id: "windows98", name: "Windows 98", color: "#0067B8", logo: "windows" },
  { id: "windowsme", name: "Windows Me", color: "#2A9D8F", logo: "windows" },
  { id: "windows2000", name: "Windows 2000", color: "#1E5AA8", logo: "windows" },
  { id: "windowsxp", name: "Windows XP", color: "#357EC7", logo: "windows" },
  { id: "windowsvista", name: "Windows Vista", color: "#4B70A5", logo: "windows" },
  { id: "windows7", name: "Windows 7", color: "#00A4EF", logo: "windows" },
  { id: "windows10", name: "Windows 10", color: "#0078D4", logo: "windows" },
  { id: "windows11", name: "Windows 11", color: "#0078D4", logo: "windows" },
  { id: "osx", name: "OS X", color: "#6F7782", logo: "apple" },
  { id: "macos", name: "macOS", color: "#111111", logo: "apple" }
];

const emptyState = () => ({ pool: distros.map((distro) => distro.id), "1": [], "2": [], "3": [], "4": [], "5": [] });
const byId = Object.fromEntries(distros.map((distro) => [distro.id, distro]));
let zones = load();
let selected = null;

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem("classifica-linux-locale-v1"));
    if (saved && ["pool", "1", "2", "3", "4", "5"].every((zone) => Array.isArray(saved[zone]))) {
      const validIds = new Set(distros.map((distro) => distro.id));
      const alreadyPresent = new Set();
      ["pool", "1", "2", "3", "4", "5"].forEach((zone) => {
        saved[zone] = saved[zone].filter((id) => validIds.has(id) && !alreadyPresent.has(id));
        saved[zone].forEach((id) => alreadyPresent.add(id));
      });
      distros.forEach((distro) => { if (!alreadyPresent.has(distro.id)) saved.pool.push(distro.id); });
      return saved;
    }
  } catch (_) {}
  return emptyState();
}

function save() { localStorage.setItem("classifica-linux-locale-v1", JSON.stringify(zones)); }

function card(id) {
  const distro = byId[id];
  const button = document.createElement("button");
  button.className = "distro-card";
  button.draggable = true;
  button.type = "button";
  button.title = "Trascina oppure fai clic";
  button.setAttribute("aria-label", `Sposta ${distro.name}`);
  button.innerHTML = `<span class="logo-disc" style="background-color:${distro.color}"><img src="logos/${distro.logo || distro.id}.svg" alt=""></span><span>${distro.name}</span><span class="grab" aria-hidden="true">⠿</span>`;
  button.addEventListener("dragstart", (event) => { event.dataTransfer.setData("text/plain", id); event.dataTransfer.effectAllowed = "move"; });
  button.addEventListener("click", (event) => { event.stopPropagation(); selected = id; renderSelection(); });
  return button;
}

function move(id, destination) {
  Object.keys(zones).forEach((zone) => { zones[zone] = zones[zone].filter((item) => item !== id); });
  zones[destination].push(id);
  selected = null;
  save();
  render();
}

function render() {
  document.querySelectorAll("[data-zone]").forEach((container) => {
    const zone = container.dataset.zone;
    container.innerHTML = "";
    zones[zone].forEach((id) => container.appendChild(card(id)));
    if (!zones[zone].length) {
      const message = document.createElement(zone === "pool" ? "p" : "span");
      message.className = zone === "pool" ? "all-done" : "empty-label";
      message.textContent = zone === "pool" ? "Classifica completata. Adesso preparati alle proteste nei commenti." : "Trascina qui";
      container.appendChild(message);
    }
  });
  document.getElementById("remaining").textContent = `${zones.pool.length} da classificare`;
  renderSelection();
}

function renderSelection() {
  const bar = document.getElementById("selection");
  bar.hidden = !selected;
  if (selected) document.getElementById("selected-name").textContent = byId[selected].name;
  document.querySelectorAll("[data-zone]").forEach((zone) => zone.classList.toggle("is-target", Boolean(selected)));
}

document.querySelectorAll("[data-zone]").forEach((container) => {
  container.addEventListener("dragover", (event) => event.preventDefault());
  container.addEventListener("drop", (event) => { event.preventDefault(); const id = event.dataTransfer.getData("text/plain"); if (byId[id]) move(id, container.dataset.zone); });
  container.addEventListener("click", () => { if (selected) move(selected, container.dataset.zone); });
});
document.getElementById("cancel").addEventListener("click", () => { selected = null; renderSelection(); });
document.getElementById("reset").addEventListener("click", () => {
  if (confirm("Vuoi davvero azzerare tutta la classifica?")) { zones = emptyState(); selected = null; save(); render(); }
});
render();
